package com.proactivesensing.bobbydouglass.proactiveone.configure_options;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import com.bignerdranch.expandablerecyclerview.ViewHolder.ParentViewHolder;
import com.proactivesensing.bobbydouglass.proactiveone.R;

public class TitleParentViewHolder extends ParentViewHolder {
    public TextView _textView;
    public ImageView _imageView;

    public TitleParentViewHolder(View itemView) {
        super(itemView);
        _textView = (TextView)itemView.findViewById(R.id.textView);
        _imageView = (ImageView) itemView.findViewById(R.id.imageView);
    }
}

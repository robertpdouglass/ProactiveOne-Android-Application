package com.proactivesensing.bobbydouglass.proactiveone;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;

public class Configure extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.configure);
    }

    public void sensor(View view) {
        startActivity(new Intent(this, Configure_Sensors.class));
    }

    public void data(View view) {
        startActivity(new Intent(this, Configure_Data.class));
    }

    public void options(View view) {
        startActivity(new Intent(this, Configure_Options.class));
    }

    @Override
    public void onBackPressed() {
        Intent intent = new Intent(this, Home.class);
        startActivity(intent);
    }
}

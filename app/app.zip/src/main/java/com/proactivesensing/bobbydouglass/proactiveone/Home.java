package com.proactivesensing.bobbydouglass.proactiveone;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Home extends AppCompatActivity {

    public Context c;
    public static boolean once = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.home);
        final String PREFS_NAME = "Preferences";
        SharedPreferences settings = getSharedPreferences(PREFS_NAME, 0);
        boolean firstTime = false;
        c = getApplicationContext();

        if (settings.getBoolean("firstTime", true)) {
            firstTime = true;
            settings.edit().putBoolean("firstTime", false).commit();
        }
        Modbus m = new Modbus(c, firstTime);
    }

    public Context getContext() {
        return c;
    }

    public void programming(View view) {
        startActivity(new Intent(this, Read_Programming.class));
    }

    public void configure(View view) {
        startActivity(new Intent(this, Configure.class));
    }

    public void sensors(View view) {
        startActivity(new Intent(this, Read_Sensors.class));
    }

    @Override
    public void onBackPressed() {
        //kill process
    }
}

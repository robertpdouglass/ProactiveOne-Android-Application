package com.proactivesensing.bobbydouglass.proactiveone.configure_options;

import android.content.Context;
import android.os.Build;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.TimePicker;
import android.widget.ToggleButton;

import com.bignerdranch.expandablerecyclerview.Adapter.ExpandableRecyclerAdapter;
import com.bignerdranch.expandablerecyclerview.Model.ParentObject;
import com.proactivesensing.bobbydouglass.proactiveone.Modbus;
import com.proactivesensing.bobbydouglass.proactiveone.R;
import java.util.List;

public class MyAdapter extends ExpandableRecyclerAdapter<TitleParentViewHolder,TitleChildViewHolder> {

    public static Modbus[] changes;
    public static boolean[] changes_bool;
    public static boolean changes_made = false;

    LayoutInflater inflater;
    Context c;
    int index;
    View view;
    boolean enabled;

    public MyAdapter(Context context, List<ParentObject> parentItemList, int i) {
        super(context, parentItemList);
        inflater = LayoutInflater.from(context);
        c = context;
        index = i;
        changes = new Modbus[10];
        changes_bool = new boolean[10];
        for(int j = 0; j < 10; j++) {
            changes[j] = new Modbus(c, false);
            changes_bool[j] = false;
        }
    }

    @Override
    public TitleParentViewHolder onCreateParentViewHolder(ViewGroup viewGroup) {
        View view = inflater.inflate(R.layout.title_parent, viewGroup, false);
        return new TitleParentViewHolder(view);
    }

    @Override
    public TitleChildViewHolder onCreateChildViewHolder(ViewGroup viewGroup) {
        switch(index) {
            case 0:
                view = inflater.inflate(R.layout.z_locations_per_day_child, viewGroup, false);
                break;
            case 1:
                view = inflater.inflate(R.layout.z_time_daily_gps_msg_child, viewGroup, false);
                break;
            case 2:
                view = inflater.inflate(R.layout.z_auto_location_child, viewGroup, false);
                break;
            case 3:
                view = inflater.inflate(R.layout.z_a_msg_per_day_child, viewGroup, false);
                break;
            case 4:
                view = inflater.inflate(R.layout.z_a_time_daily_msg_child, viewGroup, false);
                break;
            case 5:
                view = inflater.inflate(R.layout.z_b_msg_per_day_child, viewGroup, false);
                break;
            case 6:
                view = inflater.inflate(R.layout.z_b_time_daily_msg_child, viewGroup, false);
                break;
            case 7:
                view = inflater.inflate(R.layout.z_battery_child, viewGroup, false);
                break;
            case 8:
                view = inflater.inflate(R.layout.z_sensor_cycle_child, viewGroup, false);
                break;
            case 9:
                view = inflater.inflate(R.layout.z_vcc_wait_time_child, viewGroup, false);
                break;
        }
        return new TitleChildViewHolder(view);
    }

    @Override
    public void onBindParentViewHolder(TitleParentViewHolder titleParentViewHolder, int i, Object o) {
        TitleParent title = (TitleParent)o;
        titleParentViewHolder._textView.setText(title.getTitle());
    }

    @Override
    public void onBindChildViewHolder(TitleChildViewHolder titleChildViewHolder, int i, Object o) {
        final TitleChildViewHolder t = new TitleChildViewHolder(view);
        switch(index) {
            case 0:
                t.locationsPerDay.setText("" + new Modbus(c, 1001).getValue());
                t.locationsPerDay.addTextChangedListener(new TextWatcher() {
                    @Override
                    public void afterTextChanged(Editable s) {}

                    @Override
                    public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                    }

                    @Override
                    public void onTextChanged(CharSequence s, int start, int before, int count) {
                        if(s.length() != 0) {
                            changes[0] = new Modbus(c, 1001, Integer.parseInt(s.toString()));
                            changes_made = true;
                            changes_bool[0] = true;
                        }
                    }
                });

                t.locationsPerDayPlus.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        changes[0] = new Modbus(c, 1001, new Modbus(c, 1001).getValue() + 1);
                        changes_made = true;
                        changes_bool[0] = true;
                        t.locationsPerDay.setText("" + new Modbus(c, 1001).getValue());
                    }
                });

                t.locationsPerDayMinus.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        changes[0] = new Modbus(c, 1001, new Modbus(c, 1001).getValue() - 1);
                        changes_made = true;
                        changes_bool[0] = true;
                        t.locationsPerDay.setText("" + new Modbus(c, 1004).getValue());
                    }
                });
                break;
            case 1:
                if (Build.VERSION.SDK_INT >= 23 ) {
                    t.firstGpsMsg.setHour(new Modbus(c, 1002).getValue() / 60);
                    t.firstGpsMsg.setMinute(new Modbus(c, 1002).getValue() % 60);
                }
                else {
                    t.firstGpsMsg.setCurrentHour(new Modbus(c, 1002).getValue() / 60);
                    t.firstGpsMsg.setCurrentMinute(new Modbus(c, 1002).getValue() % 60);
                }

                t.firstGpsMsg.setOnTimeChangedListener(new TimePicker.OnTimeChangedListener() {
                    @Override
                    public void onTimeChanged(TimePicker view, int hourOfDay, int minute) {
                        changes[1] = new Modbus(c, 1002, ((hourOfDay * 60) + minute));
                        changes_bool[1] = true;
                        changes_made = true;
                    }
                });
                break;
            case 2:
                t.autoLocationEditText.addTextChangedListener(new TextWatcher() {
                    @Override
                    public void afterTextChanged(Editable s) {}

                    @Override
                    public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                    }

                    @Override
                    public void onTextChanged(CharSequence s, int start, int before, int count) {
                        if(s.length() != 0) {
                            changes[2] = new Modbus(c, 1003, Integer.parseInt(s.toString()));
                            changes_made = true;
                            changes_bool[2] = true;
                        }
                    }
                });

                if(enabled) {
                    t.autoLocationEditText.setText("" + new Modbus(c, 1003).getValue());
                }
                else {
                    t.autoLocationEditText.setEnabled(enabled);
                }
                break;
            case 3:
                t.aMsgPerDay.setText("" + new Modbus(c, 1004).getValue());
                t.aMsgPerDay.addTextChangedListener(new TextWatcher() {
                    @Override
                    public void afterTextChanged(Editable s) {}

                    @Override
                    public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                    }

                    @Override
                    public void onTextChanged(CharSequence s, int start, int before, int count) {
                        if(s.length() != 0) {
                            changes[3] = new Modbus(c, 1004, Integer.parseInt(s.toString()));
                            changes_made = true;
                            changes_bool[3] = true;
                        }
                    }
                });

                t.aMsgPerDayPlus.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        changes[3] = new Modbus(c, 1004, new Modbus(c, 1004).getValue() + 1);
                        changes_made = true;
                        changes_bool[3] = true;
                        t.aMsgPerDay.setText("" + new Modbus(c, 1004).getValue());
                    }
                });

                t.aMsgPerDayMinus.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        changes[3] = new Modbus(c, 1004, new Modbus(c, 1004).getValue() - 1);
                        changes_made = true;
                        changes_bool[3] = true;
                        t.aMsgPerDay.setText("" + new Modbus(c, 1004).getValue());
                    }
                });
                break;
            case 4:
                if (Build.VERSION.SDK_INT >= 23 ) {
                    t.aTimeDailyMsg.setHour(new Modbus(c, 1005).getValue() / 60);
                    t.aTimeDailyMsg.setMinute(new Modbus(c, 1005).getValue() % 60);
                }
                else {
                    t.aTimeDailyMsg.setCurrentHour(new Modbus(c, 1005).getValue() / 60);
                    t.aTimeDailyMsg.setCurrentMinute(new Modbus(c, 1005).getValue() % 60);
                }

                t.aTimeDailyMsg.setOnTimeChangedListener(new TimePicker.OnTimeChangedListener() {
                    @Override
                    public void onTimeChanged(TimePicker view, int hourOfDay, int minute) {
                        changes[4] = new Modbus(c, 1005, ((hourOfDay * 60) + minute));
                        changes_bool[4] = true;
                        changes_made = true;
                    }
                });
                break;
            case 5:
                t.bMsgPerDay.setText("" + new Modbus(c, 1006).getValue());
                t.bMsgPerDay.addTextChangedListener(new TextWatcher() {
                    @Override
                    public void afterTextChanged(Editable s) {}

                    @Override
                    public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                    }

                    @Override
                    public void onTextChanged(CharSequence s, int start, int before, int count) {
                        if(s.length() != 0) {
                            changes[5] = new Modbus(c, 1006, Integer.parseInt(s.toString()));
                            changes_made = true;
                            changes_bool[5] = true;
                        }
                    }
                });

                t.bMsgPerDayPlus.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        changes[5] = new Modbus(c, 1006, new Modbus(c, 1006).getValue() + 1);
                        changes_made = true;
                        changes_bool[5] = true;
                        t.bMsgPerDay.setText("" + new Modbus(c, 1006).getValue());
                    }
                });

                t.bMsgPerDayMinus.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        changes[5] = new Modbus(c, 1006, new Modbus(c, 1006).getValue() - 1);
                        changes_made = true;
                        changes_bool[5] = true;
                        t.bMsgPerDay.setText("" + new Modbus(c, 1006).getValue());
                    }
                });
                break;
            case 6:
                if (Build.VERSION.SDK_INT >= 23 ) {
                    t.bTimeDailyMsg.setHour(new Modbus(c, 1007).getValue() / 60);
                    t.bTimeDailyMsg.setMinute(new Modbus(c, 1007).getValue() % 60);
                }
                else {
                    t.bTimeDailyMsg.setCurrentHour(new Modbus(c, 1007).getValue() / 60);
                    t.bTimeDailyMsg.setCurrentMinute(new Modbus(c, 1007).getValue() % 60);
                }

                t.bTimeDailyMsg.setOnTimeChangedListener(new TimePicker.OnTimeChangedListener() {
                    @Override
                    public void onTimeChanged(TimePicker view, int hourOfDay, int minute) {
                        changes[6] = new Modbus(c, 1007, ((hourOfDay * 60) + minute));
                        changes_bool[6] = true;
                        changes_made = true;
                    }
                });
                break;
            case 7:
                t.batteryEditText.setText("" + new Modbus(c, 1009).getValue());
                t.batteryEditText.addTextChangedListener(new TextWatcher() {
                    @Override
                    public void afterTextChanged(Editable s) {}

                    @Override
                    public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                    }

                    @Override
                    public void onTextChanged(CharSequence s, int start, int before, int count) {
                        if(s.length() != 0) {
                            changes[7] = new Modbus(c, 1009, Integer.parseInt(s.toString()));
                            changes_made = true;
                            changes_bool[7] = true;
                        }
                    }
                });
                break;
            case 8:
                t.sensorCycleTime.setText("" + new Modbus(c, 1020).getValue());
                t.sensorCycleTime.addTextChangedListener(new TextWatcher() {
                    @Override
                    public void afterTextChanged(Editable s) {}

                    @Override
                    public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                    }

                    @Override
                    public void onTextChanged(CharSequence s, int start, int before, int count) {
                        if(s.length() != 0) {
                            changes[8] = new Modbus(c, 1020, Integer.parseInt(s.toString()));
                            changes_made = true;
                            changes_bool[8] = true;
                        }
                    }
                });
                break;
            case 9:
                t.vccWaitTime.setText("" + new Modbus(c, 1021).getValue());
                t.vccWaitTime.addTextChangedListener(new TextWatcher() {
                    @Override
                    public void afterTextChanged(Editable s) {}

                    @Override
                    public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                    }

                    @Override
                    public void onTextChanged(CharSequence s, int start, int before, int count) {
                        if(s.length() != 0) {
                            changes[9] = new Modbus(c, 1021, Integer.parseInt(s.toString()));
                            changes_bool[9] = true;
                            changes_made = true;
                        }
                    }
                });
                break;
        }
    }
}


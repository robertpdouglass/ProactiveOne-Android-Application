package com.proactivesensing.bobbydouglass.proactiveone.configure_options;

public class TitleChild {

    public TitleChild() {}
}

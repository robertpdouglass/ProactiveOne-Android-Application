package com.proactivesensing.bobbydouglass.proactiveone;

import android.content.ContentValues;
import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class Modbus extends SQLiteOpenHelper {

    /* *************** Values **************** Values *************** Values *************** Values *************** Values *************** */
    /* ************* Modbus 1000 ************* */
    int locations_per_day = 1;           // 1001  0
    int time_daily_msg = (6 * 60);       // 1002  1
    int auto_location = 0;               // 1003  2
    int a_sensor_msg = 0;                // 1004  3
    int a_sensor_time = (7 * 60);        // 1005  4
    int b_sensor_msg = 0;                // 1006  5
    int b_sensor_time = (8 * 60);        // 1007  6
    int battery_low_alarm = 15;          // 1009  7
    int sensor_cycle = 20;               // 1020  8
    int vcc_wait_scan = 2;               // 1021  9
    /* ************* Modbus 1000 ************* */


    /* ************* Modbus 1100 ************* */
    int sensor_input_1_config = 1;       // 1100  10
    int sensor_input_1_recog = 3;        // 1101  11
    int sensor_1_analog_low = 0;         // 1102  12
    int sensor_1_analog_high = 100;      // 1103  13
    int sensor_1_calibration = 0;        // 1104  14
    int sensor_1_multiplier = 1;         // 1105  15
    int sensor_1_low_1 = 0;              // 1106  16
    int sensor_1_high_1 = 100;           // 1107  17
    int sensor_1_low_2 = 0;              // 1108  18
    int sensor_1_high_2 = 100;           // 1109  19
    int sensor_1_low_3 = 0;              // 1110  20
    int sensor_1_high_3 = 100;           // 1111  21
    int sensor_1_low_4 = 0;              // 1112  22
    int sensor_1_high_4 = 100;           // 1113  23

    int sensor_input_2_config = 1;       // 1114  24
    int sensor_input_2_recog = 3;        // 1115  25
    int sensor_2_analog_low = 0;         // 1116  26
    int sensor_2_analog_high = 100;      // 1117  27
    int sensor_2_calibration = 0;        // 1118  28
    int sensor_2_multiplier = 1;         // 1119  29
    int sensor_2_low_1 = 0;              // 1120  30
    int sensor_2_high_1 = 100;           // 1121  31
    int sensor_2_low_2 = 0;              // 1122  32
    int sensor_2_high_2 = 100;           // 1123  33
    int sensor_2_low_3 = 0;              // 1124  34
    int sensor_2_high_3 = 100;           // 1125  35
    int sensor_2_low_4 = 0;              // 1126  36
    int sensor_2_high_4 = 100;           // 1127  37

    int sensor_input_3_config = 1;       // 1128  38
    int sensor_input_3_recog = 3;        // 1129  39
    int sensor_3_analog_low = 0;         // 1130  40
    int sensor_3_analog_high = 100;      // 1131  41
    int sensor_3_calibration = 0;        // 1132  42
    int sensor_3_multiplier = 1;         // 1133  43
    int sensor_3_low_1 = 0;              // 1134  44
    int sensor_3_high_1 = 100;           // 1135  45
    int sensor_3_low_2 = 0;              // 1136  46
    int sensor_3_high_2 = 100;           // 1137  47
    int sensor_3_low_3 = 0;              // 1138  48
    int sensor_3_high_3 = 100;           // 1139  49
    int sensor_3_low_4 = 0;              // 1140  50
    int sensor_3_high_4 = 100;           // 1141  51

    int sensor_input_4_config = 1;       // 1142  52
    int sensor_input_4_recog = 3;        // 1143  53
    int sensor_4_analog_low = 0;         // 1144  54
    int sensor_4_analog_high = 100;      // 1145  55
    int sensor_4_calibration = 0;        // 1146  56
    int sensor_4_multiplier = 1;         // 1147  57
    int sensor_4_low_1 = 0;              // 1148  58
    int sensor_4_high_1 = 100;           // 1149  59
    int sensor_4_low_2 = 0;              // 1150  60
    int sensor_4_high_2 = 100;           // 1151  61
    int sensor_4_low_3 = 0;              // 1152  62
    int sensor_4_high_3 = 100;           // 1153  63
    int sensor_4_low_4 = 0;              // 1154  64
    int sensor_4_high_4 = 100;           // 1155  65
    /* ************* Modbus 1100 ************* */

    /* ************* Modbus 1500 ************* */
    int data_a1_source = 0;              // 1500  66
    int data_a2_source = 0;              // 1501  67
    int data_a3_source = 0;              // 1502  68
    int data_a4_source = 0;              // 1503  69
    int data_a5_source = 0;              // 1504  70
    int data_b6_source = 0;              // 1505  71
    int data_b7_source = 0;              // 1506  72
    int data_b8_source = 0;              // 1507  73
    int data_b9_source = 0;              // 1508  74
    int data_b10_source = 0;             // 1509  75
    int data_b11_source = 0;             // 1510  76
    int data_b12_source = 0;             // 1511  77
    /* ************* Modbus 1500 ************* */

    /* **************** Arrays *************** */
    final int AMOUNT = 78;

    int[] address = {1001, 1002, 1003, 1004, 1005, 1006, 1007, 1009, 1020, 1021, 1100, 1101, 1102, 1103,
    1104, 1105, 1106, 1107, 1108, 1109, 1110, 1111, 1112, 1113, 1114, 1115, 1116, 1117, 1118, 1119,
    1120, 1121, 1122, 1123, 1124, 1125, 1126, 1127, 1128, 1129, 1130, 1131, 1132, 1133, 1134, 1135,
    1136, 1137, 1138, 1139, 1140, 1141, 1142, 1143, 1144, 1145, 1146, 1147, 1148, 1149, 1150, 1151,
    1152, 1153, 1154, 1155, 1500, 1501, 1502, 1503, 1504, 1505, 1506, 1507, 1508, 1509, 1510, 1511};

    public static int[] values = new int[78];
    /* *************** Arrays ************** */

    /* *********** Stored Values *********** */
    int m_address;
    int m_value;
    int m_index;
    Context context;
    /* *********** Stored Values *********** */

    /* ************* SQL Stuff ************* */
    public static final String DATABASE_NAME = "Modbus.db";
    public static final int DATABASE_VERSION = 2;
    public static final String TABLE_NAME = "ProactiveOne";
    public static final String BASE_NAME = "modbus_";
    public static final String SQL_DELETE_ENTRIES = "DROP TABLE IF EXISTS ProactiveOne";

    SQLiteDatabase sql;
    static boolean once = false;
    /* ************* SWL Stuff ************* */
    /* *************** Values ************** Values S*************** Values *************** Values *************** Values *************** */

    public Modbus(Context c, boolean firstTime) {
        super(c, DATABASE_NAME, null, DATABASE_VERSION);
        sql = getWritableDatabase();
        context = c;
        if(firstTime) {
            constructSQLiteTable(sql);
            setup();
            insertValues();
            updateValues();
            readValues();
        }
        else {
            readValues();
        }
        //count = 0;
    }

    public Modbus(Context c, int add, int val) {
        super(c, DATABASE_NAME, null, DATABASE_VERSION);
        sql = getWritableDatabase();
        if(addressExists(add)) {
            m_address = add;
            m_value = val;
            m_index = getIndex(add);
            sql = getWritableDatabase();
            saveToArray();
        }
        else {
            Log.e("ERROR", "ADDRESS DOES NOT EXIST");
        }
    }

    public Modbus(Context c, int add) {
        super(c, DATABASE_NAME, null, DATABASE_VERSION);
        sql = getWritableDatabase();
        if(addressExists(add)) {
            m_address = add;
            m_index = getIndex(add);
            m_value = values[m_index];
        }
        else {
            Log.e("ERROR", "ADDRESS DOES NOT EXIST");
        }
    }

    @Override
    public void onCreate(SQLiteDatabase db) {}

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL(SQL_DELETE_ENTRIES);
        onCreate(db);
    }

    @Override
    public void onDowngrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        onUpgrade(db, oldVersion, newVersion);
    }


    public void constructSQLiteTable(SQLiteDatabase db) {
        String str = "CREATE TABLE IF NOT EXISTS ProactiveOne(id INTEGER PRIMARY KEY,";
        for(int i = 0; i < AMOUNT-1; i++)
            str = str + BASE_NAME + Integer.toString(address[i]) + " INTEGER,";
        str = str + BASE_NAME + Integer.toString(address[77]) + " INTEGER)";
        db.execSQL(str);
    }

    public void setup() {
        int[] values_temp = {locations_per_day, time_daily_msg, auto_location,
                a_sensor_msg, a_sensor_time, b_sensor_msg, b_sensor_time, battery_low_alarm,
                sensor_cycle, vcc_wait_scan, sensor_input_1_config, sensor_input_1_recog, sensor_1_analog_low,
                sensor_1_analog_high, sensor_1_calibration, sensor_1_multiplier, sensor_1_low_1, sensor_1_high_1,
                sensor_1_low_2, sensor_1_high_2, sensor_1_low_3, sensor_1_high_3, sensor_1_low_4,
                sensor_1_high_4, sensor_input_2_config, sensor_input_2_recog, sensor_2_analog_low, sensor_2_analog_high,
                sensor_2_calibration, sensor_2_multiplier, sensor_2_low_1, sensor_2_high_1, sensor_2_low_2,
                sensor_2_high_2, sensor_2_low_3, sensor_2_high_3, sensor_2_low_4, sensor_2_high_4,
                sensor_input_3_config, sensor_input_3_recog, sensor_3_analog_low, sensor_3_analog_high, sensor_3_calibration,
                sensor_3_multiplier, sensor_3_low_1, sensor_3_high_1, sensor_3_low_2, sensor_3_high_2,
                sensor_3_low_3, sensor_3_high_3, sensor_3_low_4, sensor_3_high_4, sensor_input_4_config,
                sensor_input_4_recog, sensor_4_analog_low, sensor_4_analog_high, sensor_4_calibration, sensor_4_multiplier,
                sensor_4_low_1, sensor_4_high_1, sensor_4_low_2, sensor_4_high_2, sensor_4_low_3,
                sensor_4_high_3, sensor_4_low_4, sensor_4_high_4, data_a1_source, data_a2_source,
                data_a3_source, data_a4_source, data_a5_source, data_b6_source, data_b7_source,
                data_b8_source, data_b9_source, data_b10_source, data_b11_source, data_b12_source};
       for(int i = 0; i < AMOUNT; i++) {
           values[i] = values_temp[i];
       }
    }

    public void insertValues() {
        ContentValues cv = new ContentValues();
        for(int i = 0; i < AMOUNT; i++)
            cv.put(BASE_NAME + address[i], values[i]);
        sql.insert(TABLE_NAME, null, cv);
    }

    public void readValues() {
        String str = "SELECT * FROM " + TABLE_NAME;
        Cursor c = sql.rawQuery(str, null);
        c.moveToFirst();
        for(int i = 0; i < AMOUNT; i++)
            values[i] = c.getInt(1 + i);
        c.close();
    }

    public void updateValue() {
        if(address[m_index] == 1001 && Home.once) {
            String command = "UPDATE " + TABLE_NAME + " SET " + BASE_NAME + address[m_index] + " = ";
            command = command + values[m_index] + ";";
            sql.execSQL(command);
            Home.once = false;
        }
        else {
            String command = "UPDATE " + TABLE_NAME + " SET " + BASE_NAME + address[m_index] + " = ";
            command = command + values[m_index] + ";";
            sql.execSQL(command);
        }
        if(m_index == 0) {
            Log.e("address", BASE_NAME + address[m_index]);
            Log.e("value", "" + values[m_index]);

            String str = "SELECT * FROM " + TABLE_NAME;
            Cursor c = sql.rawQuery(str, null);
            c.moveToFirst();
            Log.e("after", "" + c.getInt(1));
            c.close();
        }
    }

    public void updateValues() {
        for(int i = 0; i < AMOUNT; i++) {
            String command = "UPDATE " + TABLE_NAME + " SET " + BASE_NAME + address[i] + " = ";
            command = command + values[i] + ";";
            sql.execSQL(command);
        }
    }

    public void cancelChanges() {
        readValues();
    }

    public void save() {
        saveToArray();
        updateValue();
        readValues();
    }

    public void saveToArray() {
        values[m_index] = m_value;
    }

    public void setValue(int val) {
        m_value = val;
    }

    public int getAddress() {
        return m_address;
    }

    public int getValue() {
        return values[m_index];
    }

    public int getIndex() {
        return m_index;
    }

    public boolean addressExists(int add) {
        for(int i = 0; i < AMOUNT; i++) {
            if(address[i] == add) {
                return true;
            }
        }
        return false;
    }

    public int getIndex(int add) {
        for(int i = 0; i < AMOUNT; i++) {
            if(address[i] == add) {
                return i;
            }
        }
        return -1;
    }
}

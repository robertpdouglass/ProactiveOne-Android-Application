package com.proactivesensing.bobbydouglass.proactiveone.configure_options;

import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TimePicker;
import android.widget.ToggleButton;
import com.bignerdranch.expandablerecyclerview.ViewHolder.ChildViewHolder;
import com.proactivesensing.bobbydouglass.proactiveone.R;

public class TitleChildViewHolder extends ChildViewHolder {

    public static TimePicker firstGpsMsg, aTimeDailyMsg, bTimeDailyMsg;
    public static EditText locationsPerDay, autoLocationEditText, aMsgPerDay, bMsgPerDay, batteryEditText;
    public static EditText sensorCycleTime, vccWaitTime;
    public static ToggleButton autoLocationButton;
    public static Button locationsPerDayPlus, locationsPerDayMinus, aMsgPerDayPlus, aMsgPerDayMinus, bMsgPerDayPlus, bMsgPerDayMinus;

    public TitleChildViewHolder(View itemView) {
        super(itemView);

        locationsPerDay = (EditText) itemView.findViewById(R.id.locations_per_day);
        locationsPerDayPlus = (Button) itemView.findViewById(R.id.buttonPos);
        locationsPerDayMinus = (Button) itemView.findViewById(R.id.buttonNeg);
        firstGpsMsg = (TimePicker) itemView.findViewById(R.id.dailyGpsMsg);
        autoLocationButton = (ToggleButton) itemView.findViewById(R.id.auto_button);
        autoLocationEditText = (EditText) itemView.findViewById(R.id.auto_editText);
        aMsgPerDay = (EditText) itemView.findViewById(R.id.a_msg_per_day);
        aMsgPerDayPlus = (Button) itemView.findViewById(R.id.buttonAMsgPos);
        aMsgPerDayMinus = (Button) itemView.findViewById(R.id.buttonAMsgNeg);
        aTimeDailyMsg = (TimePicker) itemView.findViewById(R.id.a_time_daily_msg);
        bMsgPerDay = (EditText) itemView.findViewById(R.id.b_msg_per_day);
        bMsgPerDayPlus = (Button) itemView.findViewById(R.id.buttonBMsgPos);
        bMsgPerDayMinus = (Button) itemView.findViewById(R.id.buttonBMsgNeg);
        bTimeDailyMsg = (TimePicker) itemView.findViewById(R.id.b_time_daily_msg);
        batteryEditText = (EditText) itemView.findViewById(R.id.battery_editText);
        sensorCycleTime = (EditText) itemView.findViewById(R.id.sensor_cycle);
        vccWaitTime = (EditText) itemView.findViewById(R.id.vcc_wait);
    }
}

package com.proactivesensing.bobbydouglass.proactiveone.configure_options;

import android.content.Context;
import java.util.ArrayList;
import java.util.List;

public class TitleCreator {
    static TitleCreator _titleCreator;
    List<TitleParent> _titleParents;

    public TitleCreator(Context context, int index) {
        _titleParents = new ArrayList<>();
        String[] items = new String[]{"Locations Per Day", "Time Of First Daily GPS Message",
                                      "Auto Location On Movement", "A Sensor Messages Per Day",
                                      "Time Of First Daily Sensor A Message", "B Sensor Messages Per Day",
                                      "Time Of First Daily Sensor B Message", "Battery Alarm",
                                      "Sensor Cycle Time", "VCC Sensor Wait Time"};
        TitleParent title = new TitleParent(items[index]);
        _titleParents.add(title);
    }

    public static TitleCreator get(Context context, int index) {
        if(_titleCreator == null)
            _titleCreator = new TitleCreator(context, index);
        return _titleCreator;
    }

    public TitleParent getAll(int i) {
        return _titleParents.get(0);
    }
}

package com.proactivesensing.bobbydouglass.proactiveone;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;

import com.bignerdranch.expandablerecyclerview.Model.ParentObject;
import com.proactivesensing.bobbydouglass.proactiveone.configure_options.MyAdapter;
import com.proactivesensing.bobbydouglass.proactiveone.configure_options.TitleChild;
import com.proactivesensing.bobbydouglass.proactiveone.configure_options.TitleCreator;
import com.proactivesensing.bobbydouglass.proactiveone.configure_options.TitleParent;
import java.util.ArrayList;
import java.util.List;

public class Configure_Options extends AppCompatActivity {

    RecyclerView[] recyclerView = new RecyclerView[10];
    public static int index = 0;

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        for(int i = 0; i < 10; i++) {
            ((MyAdapter) recyclerView[i].getAdapter()).onSaveInstanceState(outState);
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.configure_options);

        recyclerView[0] = (RecyclerView) findViewById(R.id.recyclerView0); recyclerView[1] = (RecyclerView) findViewById(R.id.recyclerView1);
        recyclerView[2] = (RecyclerView) findViewById(R.id.recyclerView2); recyclerView[3] = (RecyclerView) findViewById(R.id.recyclerView3);
        recyclerView[4] = (RecyclerView) findViewById(R.id.recyclerView4); recyclerView[5] = (RecyclerView) findViewById(R.id.recyclerView5);
        recyclerView[6] = (RecyclerView) findViewById(R.id.recyclerView6); recyclerView[7] = (RecyclerView) findViewById(R.id.recyclerView7);
        recyclerView[8] = (RecyclerView) findViewById(R.id.recyclerView8); recyclerView[9] = (RecyclerView) findViewById(R.id.recyclerView9);

        MyAdapter[] adapter = {new MyAdapter(this, initData(0), 0), new MyAdapter(this, initData(1), 1), new MyAdapter(this, initData(2), 2),
                new MyAdapter(this, initData(3), 3), new MyAdapter(this, initData(4), 4), new MyAdapter(this, initData(5), 5),
                new MyAdapter(this, initData(6), 6), new MyAdapter(this, initData(7), 7), new MyAdapter(this, initData(8), 8),
                new MyAdapter(this, initData(9), 9)};

        for(int i = 0; i < 10; i++) {
            recyclerView[i].setLayoutManager(new LinearLayoutManager(this));
            adapter[i].setParentClickableViewAnimationDefaultDuration();
            adapter[i].setParentAndIconExpandOnClick(true);
            recyclerView[i].setAdapter(adapter[i]);
        }
    }

    @Override
    public void onBackPressed() {
        if(MyAdapter.changes_made) {
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setMessage("Changes Made, Apply Changes?");
            builder.setPositiveButton("Yes", dialogClickListener);
            builder.setNegativeButton("No", dialogClickListener);
            builder.show();
        }
    }

    DialogInterface.OnClickListener dialogClickListener = new DialogInterface.OnClickListener() {
        @Override
        public void onClick(DialogInterface dialog, int which) {
            switch (which){
                case DialogInterface.BUTTON_POSITIVE:
                    startNfc();
                    break;

                case DialogInterface.BUTTON_NEGATIVE:
                    startConfigure();
                    break;
            }
        }
    };

    public void startNfc() {
        startActivity(new Intent(this, Nfc.class));
    }

    public void startConfigure() {
        startActivity(new Intent(this, Configure.class));
    }

    private List<ParentObject> initData(int i) {
        TitleCreator titleCreator = new TitleCreator(this, i);
        TitleParent titles = titleCreator.getAll(i);
        List<ParentObject> parentObject = new ArrayList<>();
        List<Object> childList = new ArrayList<>();
        childList.add(new TitleChild());
        titles.setChildObjectList(childList);
        parentObject.add(titles);

        return parentObject;
    }

    public void restore(View view) {
        new Modbus(getApplicationContext(), true);
    }
}